({
     
    toggleSection : function(component, event, helper) {
        
        // dynamically get aura:id name from 'data-auraId' attribute
        var sectionAuraId = event.target.getAttribute("data-auraId");
        // get section Div element using aura:id
        var sectionDiv = component.find(sectionAuraId).getElement();
        /* The search() method searches for 'slds-is-open' class, and returns the position of the match.
         * This method returns -1 if no match is found.
        */
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        // -1 if 'slds-is-open' class is missing...then set 'slds-is-open' class else set slds-is-close class to element
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
    },
    toggleSection1: function(component, event, helper) {
        
         component.set("v.subTabs", true);
          var tab1 = component.find('timeLogId');
        var TabOnedata = component.find('timelogData');
        
        var tab2 = component.find('leaveId');
        var TabTwoData = component.find('leaveData');
         var tab3 = component.find('homeId');
        var tab4 = component.find('profileId');
        
        // action after selection of timelog option
        $A.util.addClass(tab1, 'listColor');
        $A.util.removeClass(tab2, 'listColor');
        $A.util.removeClass(tab3, 'listColor');
         $A.util.removeClass(tab4, 'listColor');
        
        //show and Active timelog tab
        $A.util.addClass(tab1, 'slds-active');
        $A.util.addClass(TabOnedata, 'slds-show');
        $A.util.removeClass(TabOnedata, 'slds-hide');
        // Hide and deactivate leave tab
        $A.util.removeClass(tab2, 'slds-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
       
       
    },
    
    toggleSection2: function(component, event, helper) {
        component.set("v.subTabs", true);
        var tab1 = component.find('timeLogId');
        var TabOnedata = component.find('timelogData');
        
        var tab2 = component.find('leaveId');
        var TabTwoData = component.find('leaveData');
        var tab3 = component.find('homeId');
        var tab4 = component.find('profileId');
        
        // action after selection of leave option
          $A.util.addClass(tab2, 'listColor');
        $A.util.removeClass(tab1, 'listColor');
           $A.util.removeClass(tab3, 'listColor');
          $A.util.removeClass(tab4, 'listColor');
        
        //show and Active leave Tab
        $A.util.addClass(tab2, 'slds-active');
        $A.util.removeClass(TabTwoData, 'slds-hide');
        $A.util.addClass(TabTwoData, 'slds-show');
        // Hide and deactivate timelog tab
        $A.util.removeClass(tab1, 'slds-active');
        $A.util.removeClass(TabOnedata, 'slds-show');
        $A.util.addClass(TabOnedata, 'slds-hide');
        
    },
    
    home: function(component, event, helper) {
        
        
        
        // action after selection of home option
			var tab5 = component.find('tId');
        $A.util.removeClass(tab5, 'subList');
         var tab6 = component.find('taId');
        $A.util.removeClass(tab6, 'subList');
        var tab7 = component.find('lId');
        $A.util.removeClass(tab7, 'subList');
        var tab8 = component.find('laId');
        $A.util.removeClass(tab8, 'subList');        
         
         var tab3 = component.find('homeId');
       var tab1 = component.find('timeLogId');
        var tab2 = component.find('leaveId');
         var tab4 = component.find('profileId');
        
         $A.util.addClass(tab3, 'listColor');
           $A.util.removeClass(tab1, 'listColor');
           $A.util.removeClass(tab2, 'listColor');
          $A.util.removeClass(tab4, 'listColor');
        
        
        component.set("v.subTabs", false);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/"
        });
        urlEvent.fire();
    },
    
    profile: function(component, event, helper) {
        
        // action after selection of home option 
         
        var tab5 = component.find('tId');
        $A.util.removeClass(tab5, 'subList');
         var tab6 = component.find('taId');
        $A.util.removeClass(tab6, 'subList');
        var tab7 = component.find('lId');
        $A.util.removeClass(tab7, 'subList');
        var tab8 = component.find('laId');
        $A.util.removeClass(tab8, 'subList');        
                           
        var tab3 = component.find('homeId');
       var tab1 = component.find('timeLogId');
        var tab2 = component.find('leaveId');
         var tab4 = component.find('profileId');
        $A.util.addClass(tab4, 'listColor');
        $A.util.removeClass(tab1, 'listColor');
        $A.util.removeClass(tab2, 'listColor');
        $A.util.removeClass(tab3, 'listColor');
        
        
        component.set("v.subTabs", false);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/profile"
        });
        urlEvent.fire();
    },
    
    timeLogClick: function(component, event, helper) {
        var tab5 = component.find('tId');
        $A.util.addClass(tab5, 'subList');
         var tab6 = component.find('taId');
        $A.util.removeClass(tab6, 'subList');
        var tab7 = component.find('lId');
        $A.util.removeClass(tab7, 'subList');
        var tab8 = component.find('laId');
        $A.util.removeClass(tab8, 'subList');
        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/time-log-entries/Time_Log_Entries__c"
        });
        urlEvent.fire();
    },
    
    timelogApproval: function(component, event, helper)  {
        var tab5 = component.find('tId');
        $A.util.removeClass(tab5, 'subList');
         var tab6 = component.find('taId');
        $A.util.addClass(tab6, 'subList');
        var tab7 = component.find('lId');
        $A.util.removeClass(tab7, 'subList');
        var tab8 = component.find('laId');
        $A.util.removeClass(tab8, 'subList');
        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/approvals"
        });
        urlEvent.fire();
    },
    
    LeaveClick: function(component, event, helper) {
       
         var tab5 = component.find('tId');
        $A.util.removeClass(tab5, 'subList');
         var tab6 = component.find('taId');
        $A.util.removeClass(tab6, 'subList');
        var tab7 = component.find('lId');
        $A.util.addClass(tab7, 'subList');
        var tab8 = component.find('laId');
        $A.util.removeClass(tab8, 'subList');
        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/leavelist"
        });
        urlEvent.fire();
    },
    
    leaveApproval: function(component, event, helper)  {
        var tab5 = component.find('tId');
        $A.util.removeClass(tab5, 'subList');
         var tab6 = component.find('taId');
        $A.util.removeClass(tab6, 'subList');
        var tab7 = component.find('lId');
        $A.util.removeClass(tab7, 'subList');
        var tab8 = component.find('laId');
        $A.util.addClass(tab8, 'subList');
        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/leaveapproval"
        });
        urlEvent.fire();
    }   
})