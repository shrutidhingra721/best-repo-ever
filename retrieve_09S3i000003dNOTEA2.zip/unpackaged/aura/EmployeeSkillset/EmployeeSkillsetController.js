({
    doInit : function( component, event, helper ) {
        $A.util.toggleClass(component.find('resultsDiv'),'slds-is-open');
        if( !$A.util.isEmpty(component.get('v.selectedRecords')) ) {
            helper.searchRecordsHelper(component, event, helper, component.get('v.selectedRecords'));
        }
    },
    
    
    doInit2: function(component, event, helper) {  
        var action = component.get('c.GetSkill');  
        action.setCallback(this, function(response) {    
            var state = response.getState();  
            console.log(response);
            if (state === "SUCCESS") {
                var responseValue = response.getReturnValue();
                
             /*    var commaSeperator = [];                
                for(var i=0; i < responseValue.length-1; i++){
                    commaSeperator.push(",");
                
                }
                
              console.log('bool value '+commaSeperator);                 
                
              component.set('v.commaSeperator', commaSeperator);*/
                
                component.set("v.skill", responseValue);
                component.set("v.skillLength", responseValue.length);      
                
                var resultset = JSON.stringify(responseValue);
        		console.log('in init dala h' +resultset);
            }  
        });  
        $A.enqueueAction(action);
        
    },
    
     // this function automatic call by aura:waiting event  
    showSpinner: function(component, event, helper) {
       // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
   },
    
 	// this function automatic call by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
     // make Spinner attribute to false for hide loading spinner    
       component.set("v.Spinner", false);
    },
    
    // Functionality on click of Add skill icon
    addSkills: function(component, event, helper) {        
        component.set("v.isAddPage",true);
         component.set("v.selectedRecords",[]);
        component.set("v.recordsList",[]);
        component.set("v.selectedDataObj",[]);
        component.set("v.searchString","");
        
    },
    
    // Functionality on click of Add skill icon
    editSkills : function( component, event, helper ){
        component.set('v.isEditPage', true); 
    },    
    
    //When closing the modal for add and edit both
    closeModal: function(component, event, helper) {        
        component.set("v.isAddPage",false);
        component.set("v.isEditPage",false);
        component.set("v.selectedRecords",[]);
        component.set("v.recordsList",[]);
        component.set("v.selectedDataObj",[]);
        component.set("v.searchString","");
    },
    
    
    // When a keyword is entered in search box
    searchRecords : function( component, event, helper ) {
        if( !$A.util.isEmpty(component.get('v.searchString')) ) {
            helper.searchRecordsHelper(component, event, helper, []);
        } else {
            $A.util.removeClass(component.find('resultsDiv'),'slds-is-open');
        }
    },
    
    // When an item is selected
    selectItem : function( component, event, helper ) {
        if(!$A.util.isEmpty(event.currentTarget.id)) {
            var recordsList = component.get('v.recordsList');
            var selectedRecords = component.get('v.selectedRecords') || {};
            var selectedDataObj = component.get('v.selectedDataObj') || [];
            var index = recordsList.findIndex(x => x.value === event.currentTarget.id)
            if(index != -1) {
                recordsList[index].isSelected = recordsList[index].isSelected === true ? false : true;
                if(selectedRecords.includes(recordsList[index].value)) {
                    selectedRecords.splice(selectedRecords.indexOf(recordsList[index].value), 1);
                    var ind = selectedDataObj.findIndex(x => x.value === event.currentTarget.id)
                    if(ind != -1) {selectedDataObj.splice(ind, 1)}
                } else {
                    selectedRecords.push(recordsList[index].value);
                    selectedDataObj.push(recordsList[index]);
                }
            }
            component.set('v.recordsList', recordsList);
            component.set('v.selectedRecords', selectedRecords);
            component.set('v.selectedDataObj', selectedDataObj);
          
           
        }
        $A.util.removeClass(component.find('resultsDiv'),'slds-is-open');
    },
    
    removePill : function( component, event, helper ){
        var recordId = event.getSource().get('v.name');
        var recordsList = component.get('v.recordsList');
        var selectedRecords = component.get('v.selectedRecords');
        var selectedDataObj = component.get('v.selectedDataObj');
        
        selectedRecords.splice(selectedRecords.indexOf(recordId), 1);
        var index = selectedDataObj.findIndex(x => x.value === recordId)
        if(index != -1) {
            selectedDataObj.splice(index, 1)
        }
        var ind = recordsList.findIndex(x => x.value === recordId)
        if(ind != -1) {
            recordsList[ind].isSelected = false;
        }
        component.set('v.recordsList', recordsList);
        component.set('v.selectedDataObj', selectedDataObj);
        component.set('v.selectedRecords', selectedRecords);
    },
    
    showRecords : function( component, event, helper ){
        var disabled = component.get('v.disabled');
        if(!disabled && !$A.util.isEmpty(component.get('v.recordsList')) && !$A.util.isEmpty(component.get('v.searchString'))) {
            $A.util.addClass(component.find('resultsDiv'),'slds-is-open');
        }
    },
    
    // To close the dropdown if clicked outside the inputbox.
    blurEvent : function( component, event, helper ){
        $A.util.removeClass(component.find('resultsDiv'),'slds-is-open');
    },
    
    // Add selected skills to database
    saveSkills : function( component, event, helper ){
        component.set('v.isAddPage', false);
        
        
        var selectedRecordList = component.get('v.selectedRecords') || {};
        console.log('selectedRecordList '+selectedRecordList);
        var selectedDataObj = component.get('v.selectedDataObj') || [];
        var skillList = JSON.stringify(component.get('v.skill'));
        
        var i,j;
        for(i=0;i<skillList.length;i++){
            for(j=0;j<selectedDataObj.length;j++){
                if(selectedDataObj[j] == skillList[i].skill__r){
                    alert('value is repeating');
                }
            }
        }
        
        var action = component.get('c.saveRecords');
        action.setParams({
            'selectedRecordList' : selectedRecordList       
            
        });
        var action2 = component.get('c.GetSkill');  
        action2.setCallback(this, function(response) {    
            var state = response.getState();  
            console.log(response);
            if (state === "SUCCESS") {
                var responseValue = response.getReturnValue();
                console.log('rep '+responseValue);
                component.set("v.skill", response.getReturnValue()); 
                component.set("v.skillLength", responseValue.length);   
            }  
        });  
        $A.enqueueAction(action);
        $A.enqueueAction(action2);  
    
    },
    
    deleteSkills : function( component, event, helper ){
        
        var idx = event.target.id;
       component.set('v.deletePopUp',true);
        component.set('v.rowid',idx);
		
      
    /*    //Get the account list
       var skillList = component.get("v.skill");
         console.log('skillList '+skillList);
        //Get the target object
        var selectedItem = event.currentTarget;              
        //Get the selected item index
        var index = selectedItem.dataset.record;
        skillList.splice(index, 1);
        
     //   component.set("v.skill", skillList);
        console.log('v.Skill value '+JSON.stringify(component.get("v.Skill")));
*/

    },
    
    doDelete : function(component) {
        component.set('v.deletePopUp',false);
        console.log("v.rowid "+component.get('v.rowid'));
       var action = component.get("c.saveAfterEdit");
        action.setParams({
            'rowId':component.get('v.rowid')
            
        });
         var action2 = component.get('c.GetSkill');  
        action2.setCallback(this, function(response) {    
            var state = response.getState();  
            console.log(response);
            if (state === "SUCCESS") {
                var responseValue = response.getReturnValue();
                console.log('rep '+responseValue);
                component.set("v.skill", response.getReturnValue());
                component.set("v.skillLength", responseValue.length);   

            }  
        }); 
      /*  action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                Console.log('new skills '+response.getReturnValue());
                component.set("v.skill", response.getReturnValue());
            }
        }); */
        $A.enqueueAction(action); 
        $A.enqueueAction(action2);
    },
    
    dontDelete : function(component) {
     component.set('v.deletePopUp',false);
        
    }
   
    
    
    
})