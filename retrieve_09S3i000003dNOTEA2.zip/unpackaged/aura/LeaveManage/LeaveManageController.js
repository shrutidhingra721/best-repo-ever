({
    
    doSave : function(component, event, helper) {
        var action = component.get('c.CreateLeave');
        var isDateError = component.get('v.dateValidationError');  
        if(isDateError != true){
            
        }
        action.setParams({
            con:component.get('v.applyLeave')
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state=='SUCCESS' || state=='DRAFT')
            {
            var responseValue = response.getReturnValue();
             var toastEvent = $A.get("e.force:showToast");
             toastEvent.setParams({
                 
                 title : 'Success',
                 message: 'Record saved successfully.',
                 duration:' 5000',
                 key: 'info_alt',
                 type: 'success',
                 mode: 'sticky'
             });
             toastEvent.fire();
             var urlEvent = $A.get("e.force:navigateToURL");
             urlEvent.setParams({
                 "url": "/leavelist"
             });
             urlEvent.fire();
            }
            else if(state == 'INCOMPLETE')
            {
                var responseValue = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    
                    "title": "INCOMPLETE!",
                    "message": "The record is incomplete."
                });
                toastEvent.fire();
            }
                else if(state == 'ERROR')
                {
                    var responseValue = response.getReturnValue();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        
                        title : 'ERROR',
                        message: 'Record cannot be saved.',
                        duration:' 5000',
                        key: 'info_alt',
                        type: 'error',
                        mode: 'sticky'
                    });
                    toastEvent.fire();            }
            
            
            
        },'ALL');
        $A.enqueueAction(action);
    }
   /* doSave : function(component, event, helper) {
        var  action = component.get('c.CreateLeave');
        var isDateError = component.get("v.dateValidationError");
        var isToDateError = component.get("v.dateToValidationError");
        if(isDateError != true || isToDateError != true){
            
        }
       console.log('value to save'+component.get('v.applyLeave'));
        action.setParams({
            con:component.get('v.applyLeave')
            
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state=='SUCCESS' || state=='DRAFT')
            {
               
                var responseValue = response.getReturnValue();                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                                       
                    title : 'Success',
                    message: 'Record saved successfully.', 
                     duration: '5000',
                    key: 'info_alt',
                    type: 'success',
                    mode: 'pester'
                });
                
                toastEvent.fire();
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url": "/leavelist"
                });
                urlEvent.fire();
            }
            else if(state == 'INCOMPLETE')
            {
                var responseValue = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    
                    "title": "INCOMPLETE!",
                    "message": "The record is incomplete."
                });
                toastEvent.fire();
            }
                else if(state == 'ERROR')
                {                   
                    var responseValue = response.getReturnValue();
                    console.log('error '+responseValue);
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        
                        title : 'ERROR',
                        message: 'Record cannot be saved.',
                        duration: '5000',
                        key: 'info_alt',
                        type: 'error',
                        mode: 'pester'
                    });
                    toastEvent.fire();           
                }
            
            
        },'ALL');
        $A.enqueueAction(action);
        
    }*/,
    showSpinner: function(component, event, helper) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
    },
    hideSpinner : function(component,event,helper){
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.Spinner", false);
    },
    
    
    doSubmit : function(component, event, helper) {
        var  action = component.get('c.CreateLeave');
        var action1 = component.get('c.callApprovalProcess');
         var employee= component.get("v.userInfo.Name");
       
        action.setParams({
            con:component.get('v.applyLeave'), eName: employee 
            
        });
        action1.setParams({
            con:component.get('v.applyLeave'), eName: employee 
            
        });
      action.setCallback(this,function(response){
            var state = response.getState();
            if(state=='SUCCESS')
            {
                
                var responseValue = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    mode: 'pester',
                    duration: '5000',
                    key: 'info_alt',
                    "title": "Success!",
                    type: 'success'
                   
                });
                toastEvent.fire();
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url": "/leavelist"
                });
                urlEvent.fire();
            }
            else if(state == 'INCOMPLETE')
            {
                var responseValue = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    
                    "title": "INCOMPLETE!"
                   
                });
                toastEvent.fire();
            }
                else if(state == 'ERROR')
                {
                    var responseValue = response.getReturnValue();
                    var toastEvent = $A.get("e.force:showToast");
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        
                        title : 'ERROR',
                      
                        duration: '5000',
                        key: 'info_alt',
                        type: 'error',
                        mode: 'pester'
                    });
                    toastEvent.fire();            }
            
            
        },'ALL');
        
        
        action1.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {               
                var responseValue = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                     title : 'Success',
                    message: 'Record send for Approval successfully.',
                    duration:' 5000',
                    key: 'info_alt',
                    type: 'success',
                    mode: 'sticky'
                   
                });toastEvent.fire();
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url": "/leavelist"
                });
                urlEvent.fire();
            }
            else if (state === "INCOMPLETE") {
                var responseValue = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    
                    "title": "INCOMPLETE!",
                    "message": "The record cannot be inserted."
                });
                toastEvent.fire();   
            }
                else if (state === "ERROR") {
                   
                    var responseValue = response.getReturnValue();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                          title : 'ERROR',
                        message: 'Record cannot be saved.',
                        duration:' 5000',
                        key: 'info_alt',
                        type: 'error',
                        mode: 'sticky'
                        
                    });
                    toastEvent.fire();   
                }
        },'ALL');
        
        $A.enqueueAction(action);
        $A.enqueueAction(action1);
    },
    showSpinner: function(component, event, helper) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
    },
    hideSpinner : function(component,event,helper){
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.Spinner", false);
    },
    
    doInit1 : function(component, event, helper) {
        var action = component.get("c.fetchUser");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set("v.userInfo", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    
    
    doInit2 : function(component,event,helper) {        
        var pickvar = component.get("c.getPickListValuesIntoList");
        pickvar.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS'){
                var list = response.getReturnValue();
                component.set('v.picvalue', list);
            }
            else if(state === 'ERROR'){
                alert('ERROR OCCURED.');
            }
        });
        $A.enqueueAction(pickvar);
    },
    doInit3 : function(component, event, helper) {
        var action = component.get("c.calculateWorkingDays");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
            }
        });
        $A.enqueueAction(action);
    },
    
    display : function(component, event, helper) {
        helper.dateUpdate(component, event, helper);
        var stardateTime = component.get("v.applyLeave.From_Date__c");
        var enddateTime = component.get("v.applyLeave.To_Date__c");
        var action = component.get('c.getholidays');
        action.setParams({
        });
        action.setCallback(this , function(response){
            var objectData=[];
            var responseValue = response.getReturnValue();
            console.log('responseValue',responseValue);
            
            for (var i=0; i< responseValue.length; i++)
            {
                var item = responseValue[i];                
                objectData.push(responseValue[i].ActivityDate);
            }
            
            for(var i=0;i<objectData.length;i++)
            {
                if(stardateTime == objectData[i] )
                {
                    component.set("v.dateValidationErrorHolidayFrom" , true);
                   // component.set("v.applyLeave.From_Date__c",null);
                }
                if(enddateTime == objectData[i] )
                {
                    component.set("v.dateValidationErrorHolidayTo" , true);
                    //component.set("v.applyLeave.To_Date__c",null);
                }
                
                
            }
            console.log('object',objectData);
            
        });
        $A.enqueueAction(action,false);
        component.set("v.dateValidationErrorHolidayFrom" , false);
        component.set("v.dateValidationErrorHolidayTo" , false);
    },
    
    
    onCancel : function (component, event, helper) {
        var urlEvent = $A.get("e.force:navigateToURL");  
        urlEvent.setParams({
            "url": "/s/leave"
        });
        urlEvent.fire();   
    },
    
    onPicklistSelect:function(component,event,helper)
    {
        
     
        var  action = component.get('c.checkIfLeaveIsAvaiable');
          action.setParams({
                  
              FromDate: component.get('v.applyLeave.From_Date__c'),
              ToDate:component.get('v.applyLeave.To_Date__c'),
              leaveType:component.get('v.applyLeave.Leave_Type__c')
                         });
                         
              action.setCallback(this,function(response){
                var state = response.getState();
                var a = response.getReturnValue();
                component.set('v.checkIfRemainingLeave',a);
                if(a==true)
                {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                          title : 'ERROR',
                        message: 'You have taken all '+ component.get('v.applyLeave.Leave_Type__c'),
                        duration:' 5000',
                        key: 'info_alt',
                        type: 'error',
                        mode: 'sticky'
                        
                    });
                    toastEvent.fire();   
                    
                }
              });
             $A.enqueueAction(action);
        
    }
    
})