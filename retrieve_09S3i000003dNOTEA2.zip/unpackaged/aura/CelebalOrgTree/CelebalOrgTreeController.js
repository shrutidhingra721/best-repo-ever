({
    
    //Getting Lead Employee
    getManagerList : function(component, event, helper) {
        var action = component.get("c.fetchManagerDetail");
        
        
        action.setCallback(this, function(response) {
            var state = response.getState();  
            if(state === "SUCCESS") 
            {
                component.set("v.MyManagerList", response.getReturnValue());
            } 
            else {
                console.log('Problem getting jobOpening, response state: ' + state);
            }
        });
        $A.enqueueAction(action);
    },
    
    //Getting All community users
    getAllUsers: function(component, event, helper){
        var action = component.get("c.fetchAllUsers");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set('v.AllUserList', res);
                console.log('AllUserList '+JSON.stringify(res));                
            }            
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                    errors[0].message);
                    }
                } 
                else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);    
    },
    
    //Getting Current User
    getCurrentUser: function(component, event, helper){
        var action = component.get("c.fetchCurrentUserDetail");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set('v.currentUser', res);
                console.log('res'+JSON.stringify(res));
                
            }
            
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                    errors[0].message);
                    }
                }
                else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);    
    }
    
    
    
    
})