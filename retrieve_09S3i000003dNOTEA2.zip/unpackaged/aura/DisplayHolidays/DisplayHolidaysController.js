({
	holidaydisplay : function(component, event, helper) {
        //var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");
       //component.set('v.today', today);
      //alert(today);
		helper.displayholiday(component);
        
    }
    //dislaysingleonly :function(component, event, helper) {
       // helper.displaysingle(cmp);
   // }
    

})