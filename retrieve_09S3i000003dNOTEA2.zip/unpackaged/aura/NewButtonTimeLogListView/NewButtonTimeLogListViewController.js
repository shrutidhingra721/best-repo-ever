({
	redirectToNewPage : function(component, event, helper) {
        var newUrl = window.location.hostname;
        var newCmpName = 'new-time-log';
        var completeUrl = newUrl + '/s/'+newCmpName;
        window.location.href = '../../'+newCmpName;
        
		//window.location.replace('https://celebal-deve-community-developer-edition.na112.force.com/s/new-time-log');
	}
})