({
	 doInit : function(component, event, helper) {
        var action = component.get("c.fetchUserDetail");
        var action1 = component.get("c.getEmployeeName");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set('v.oUser', res);
            }
            else if (state === "INCOMPLETE") {
                // do something
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " + 
                                        errors[0].message);
                        }
                    } else {
                        console.log("Unknown error");
                    }
                }
        });
        $A.enqueueAction(action);
         action1.setCallback(this, function(response) {    
         var state = response.getState();  
        console.log(response);
        if (state === "SUCCESS") { 
            
            component.set("v.Name", response.getReturnValue());   
        }  
    });  
    $A.enqueueAction(action1); 
    }
})