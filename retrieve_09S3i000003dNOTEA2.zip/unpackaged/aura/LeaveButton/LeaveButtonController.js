({
	handleClick : function(component, event, helper) {
         var urlEvent = $A.get("e.force:navigateToURL");
       urlEvent.setParams({
           "url": "/s/time-log-entries/Time_Log_Entries__c/Default"
       });
       urlEvent.fire();
		
	}
})