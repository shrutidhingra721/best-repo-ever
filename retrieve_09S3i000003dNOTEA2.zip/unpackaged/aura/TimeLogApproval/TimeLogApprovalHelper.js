({
    getTimeLogs : function(component, helper) {
        
        var action = component.get("c.getAllPendingTimeLog");
        action.setCallback(this,function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resultData = response.getReturnValue();
                component.set("v.totalPages", Math.ceil(response.getReturnValue().length/component.get("v.pageSize")));
                component.set("v.allData", response.getReturnValue());
                component.set("v.currentPageNumber",1);
                
                var rows = response.getReturnValue();
                if(rows.length>0){
                    component.get("v.noRecordPage", false);
                   
                    for (var i = 0; i < rows.length; i++) {
                        var row = rows[i];
                        // checking if any owner related data in row
                        if(row.Owner) {
                            row.OwnerId = row.Owner.Name;
                        }                        
                    }
                }
                
                if (rows.length===0)
                {
                    component.set("v.noRecordPage", true); 
                }
            }
            helper.buildDataTable(component, helper);
        });
        
        $A.enqueueAction(action);
    },
    
    showSuccess : function(component, event, helper) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : 'Success',
            message: 'Record created successfully.',
            duration:' 5000',
            key: 'info_alt',
            type: 'success',
            mode: 'pester'
        });
        toastEvent.fire();
    },
    
    buildDataTable : function(component, helper) {
        var data = [];
        var pageNumber = component.get("v.currentPageNumber");
        var pageSize = component.get("v.pageSize");
        var allData = component.get("v.allData");
        var last = component.get("v.last");
        
        var totalData = allData.length;
        var x = (pageNumber-1)*pageSize;
        var last;
        if(totalData < (pageNumber)*pageSize){
            last = totalData;
        }
        else{
            last = pageNumber*pageSize;            
        }
        component.set("v.next",last);
        console.log(component.get('v.currentPageNumber'));
        console.log(component.get('v.pageSize'));
        //creating data-table data
        for(; x<(pageNumber)*pageSize; x++){
            if(allData[x]){
                data.push(allData[x]);
            }
        }
      	component.set("v.timelogList", data);
    }   
});