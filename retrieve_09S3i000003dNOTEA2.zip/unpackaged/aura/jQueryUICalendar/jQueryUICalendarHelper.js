({
	displayholiday : function(cmp) {
        var action = cmp.get("c.holidayfind");
       // var objectData=[];
        
        action.setCallback(this, function(a){
            cmp.set("v.holidays", a.getReturnValue());
             /*for(var i=0;i<a.getReturnValue().length;i++)
            {
              if(a.getReturnvalue()[i].ActivityDate >= today){
           
                  objectData.push({"Name":a.getReturnValue()[i].Name});
           }
                
            }
           
            Console.log(objectData[0]);*/
            //if(a.getReturnvalue()[i].ActivityDate >= today){
            // cmp.set('v.oneholiday',objectData[0]);
            //cmp.set('v.oneholiday',a.getReturnValue()[0].Name);
            
            //Compaire two dates
            var getHolidy = cmp.get("v.holidays");
            var dateOfToday = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");
            var ActivitydateNearFuture; 
            for(var i=0; i<getHolidy.length; i++){
                if (dateOfToday < getHolidy[i].ActivityDate) {
                    cmp.set('v.oneholiday',getHolidy[i].Name);
                    break;
                }
            }
        });
        $A.enqueueAction(action);
    }
})