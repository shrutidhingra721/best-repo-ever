({

    doInit : function(component, event, helper) {
		var userId = $A.get("$SObjectType.CurrentUser.Id");
        
        component.set('v.columns', [
            
            {label: 'Name', fieldName: 'CreatedBy.FirstName', type: 'Text'},
            {label: 'No. of Days', fieldName: 'No_Of_Days__c', type: 'number'},
            {label: 'LeaveType', fieldName: 'Leave_Type__c', type: 'Text'}
            ]);
        
        var action = component.get("c.getLeaves");
        action.setParams({
            currentUserId : userId
        })
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set('v.Leaves', res);
            }
        });
        $A.enqueueAction(action);
	}
})