({
    
    doInit : function(component, event, helper) {
        
        component.set("v.showSpinner", true);
        component.set("v.bShowModal", false);
        component.set("v.noRecordPage",false);    
        component.set('v.columns',[
            {
                label: 'View',
                type: 'button-icon',
                initialWidth: 75,
                typeAttributes: {
                    iconName: 'action:preview',
                    title: 'Preview',
                    variant: 'border-filled',
                    alternativeText: 'View',
                    value: 'view'}
            },
            
            {label: 'Employee', fieldName: 'OwnerId', type: 'User',sortable:true},            
            {label: 'Leave Type', fieldName: 'Leave_Type__c', type: 'picklist', sortable: true },
            {label: 'From ', fieldName: 'From_Date__c', type: 'Date',sortable:true},
            {label: 'To', fieldName: 'To_Date__c', type: 'Date',sortable:true},
            {label: 'Status', fieldName: 'Status__c', type: 'picklist',sortable:true},
            
        ]);
            
            helper.getLeaveData(component, helper);
			component.set("v.showSpinner", false);            
            },          
            
            approveRecord: function (component, event, helper) {
            helper.approveRecords(component,event,helper);            
            },
            
            rejectRecord: function (component, event, helper) {
            if(component.get("v.selectedRowsCount") > 0){
            var action = component.get("c.rejectLeaveRecord");            
            action.setParams({
            LeaveRecord : component.get("v.selectedRecords"),            
            });
            action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {                               
            var act = component.get("c.doInit");
            $A.enqueueAction(act);
            helper.showReject(component, event, helper);
            }
            });
            $A.enqueueAction(action);
            }
            else{
            alert('Please select atleast one leave to reject');
            }            
            },
            
            handleNext : function(component, event, helper) {        
            var pageNumber = component.get("v.currentPageNumber");
            component.set("v.currentPageNumber", pageNumber+1);
            var selectRecord = component.get("v.rowId");
            helper.buildData(component, helper);
            var row = component.get("v.rowNumberOffset");
            component.set("v.rowNumberOffset", row+10);
            },
             showSpinner: function(component, event, helper) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
        },
    hideSpinner : function(component,event,helper){
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.Spinner", false);
          },
            handlePrev : function(component, event, helper) {        
            var pageNumber = component.get("v.currentPageNumber");
            component.set("v.currentPageNumber", pageNumber-1);
            helper.buildData(component, helper);
            var row = component.get("v.rowNumberOffset");
            component.set("v.rowNumberOffset", row-10);
            },
            
            handleRowAction:function(component, event, helper) {
            var action = component.get("c.getAllLeaveEntries");
            var row = event.getParam('row');          
            component.set('v.selectedRow', row); 
            component.set('v.rowId', row.Id);         
            action.setParams({
            leaveId : component.get("v.rowId")             
            });
            
            action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
            var rows = response.getReturnValue();
            component.set("v.bShowModal", true);
            }
            });
            $A.enqueueAction(action);            
            },            
            
            updateSelectedText: function (component, event,helper) {
            var selectedRows = event.getParam('selectedRows');
            var row = component.get('v.selectedRecords');
            for(var i=0;i<selectedRows.length;i++){
            if(selectedRows[i].Status__c=='Approved'|| selectedRows[i].Status__c=='Rejected' ){
            component.set('v.disableButtons',true);
        	}else{
            	component.set('v.disableButtons',false);
        		 }
    		}
    		component.set('v.selectedRowsCount', selectedRows.length);
    		var setRows=[];
    		for(var i = 0; i < selectedRows.length; i++){
    			setRows.push(selectedRows[i].Id);
			}
 			component.set('v.selectedRecords', setRows);
			var selectRecord = component.get("v.rowId");
			console.log("in next "+selectRecord);
			var actionName = event.getParam('action').name;
			if ( actionName == 'View') {
    			var viewRecordEvent = $A.get("e.force:navigateToURL");
    			viewRecordEvent.setParams({
        			"url": "/" +rowId 
    			});
    			viewRecordEvent.fire();        
		   	}
		   },
    
    	approveSingleRecord: function (component, event, helper) {
        var action = component.get("c.approveSingleLeaveRecord");
        action.setParams({
            singleLeaveRecord : component.get("v.rowId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set("v.bShowModal", true);
                var act = component.get("c.doInit");
                $A.enqueueAction(act);   
            }
        });
            $A.enqueueAction(action);
        },     
            
        rejectSingleRecord: function (component, event, helper){            
            var action = component.get("c.rejectSingleLeaveRecord");
            action.setParams({
                singleLeaveRecord : component.get("v.rowId"),    
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var res = response.getReturnValue();
                    component.set("v.bShowModal", true);
                    var act = component.get("c.doInit");                
                    $A.enqueueAction(act);
                }
            });
            $A.enqueueAction(action);   
        },
        
            closeModal:function(component, event, helper) {
                component.set("v.bShowModal", false);
            }
})