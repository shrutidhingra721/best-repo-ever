({
	doInit : function(component, event, helper) {
        var url = $A.get('$Resource.loginpage');

        component.set('v.backgroundImageURL', '/resource/1591028586000/loginpage');
    }
})