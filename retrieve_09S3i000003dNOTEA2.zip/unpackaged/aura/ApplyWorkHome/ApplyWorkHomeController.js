({
    clickSave : function(component, event, helper) {
        var action = component.get('c.CreateWFH');
        var isDateError = component.get('v.dateValidationError');  
        if(isDateError != true){
            
        }
        action.setParams({
            con:component.get('v.applyLeave')
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state=='SUCCESS' || state=='DRAFT')
            {
           // var responseValue = response.getReturnValue();
             var toastEvent = $A.get("e.force:showToast");
             toastEvent.setParams({
                 
                 title : 'Success',
                 message: 'Record saved successfully.',
                 duration:' 5000',
                 key: 'info_alt',
                 type: 'success',
                 mode: 'sticky'
             });
             toastEvent.fire();
             var urlEvent = $A.get("e.force:navigateToURL");
             urlEvent.setParams({
                 "url": "/leavelist"
             });
             urlEvent.fire();
            }
            else if(state == 'INCOMPLETE')
            {
                var responseValue = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    
                    "title": "INCOMPLETE!",
                    "message": "The record is incomplete."
                });
                toastEvent.fire();
            }
                else if(state == 'ERROR')
                {
                    var responseValue = response.getReturnValue();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        
                        title : 'ERROR',
                        message: 'Record cannot be saved.',
                        duration:' 5000',
                        key: 'info_alt',
                        type: 'error',
                        mode: 'sticky'
                    });
                    toastEvent.fire();            }
            
            
            
        },'ALL');
        $A.enqueueAction(action);
    },
    
    
    doSubmit : function(component, event, helper) {
        var  action = component.get('c.CreateWFH');
        var action1 = component.get('c.callApprovalProcess');
        var employee= component.get("v.userInfo.Name");
        
        
        action.setParams({
            con:component.get('v.applyLeave'), eName: employee  
            
        });  
        action1.setParams({
            con:component.get('v.applyLeave'), eName: employee
            
        });
        action1.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var responseValue = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    
                    title : 'Success',
                    message: 'Record send for Approval successfully.',
                    duration:' 5000',
                    key: 'info_alt',
                    type: 'success',
                    mode: 'sticky'
                });toastEvent.fire();
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url": "/leavelist"
                });
                urlEvent.fire();
            }
            else if (state === "INCOMPLETE") {
                var responseValue = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    
                    "title": "INCOMPLETE!",
                    "message": "The record cannot be inserted."
                });
                toastEvent.fire();   
            }
                else if (state === "ERROR") {
                    var responseValue = response.getReturnValue();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        
                        title : 'ERROR',
                        message: 'Record cannot be saved.',
                        duration:' 5000',
                        key: 'info_alt',
                        type: 'error',
                        mode: 'sticky'
                    });
                    toastEvent.fire();   
                }
        },'ALL');
        
        $A.enqueueAction(action);
        $A.enqueueAction(action1);
    },
    showSpinner: function(component, event, helper) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
    },
    hideSpinner : function(component,event,helper){
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.Spinner", false);
    },
    
    
    doInit1 : function(component, event, helper) {
        var action = component.get("c.fetchUser");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set("v.userInfo", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    display : function(component, event, helper) {
        helper.dateUpdate(component, event, helper);
        var stardateTime = component.get("v.applyLeave.From_Date__c");
        var enddateTime = component.get("v.applyLeave.To_Date__c");
        var action = component.get('c.getholidays');
        action.setParams({
        });
        action.setCallback(this , function(response){
            var objectData=[];
            var responseValue = response.getReturnValue();
            console.log('responseValue',responseValue);
            
            for (var i=0; i< responseValue.length; i++)
            {
                var item = responseValue[i];                
                objectData.push(responseValue[i].ActivityDate);
            }
            
            for(var i=0;i<objectData.length;i++)
            {
                if(stardateTime == objectData[i] )
                {
                    component.set("v.dateValidationErrorHolidayFrom" , true);
                   // component.set("v.applyLeave.From_Date__c",null);
                }
                if(enddateTime == objectData[i])
                {
                    component.set("v.dateValidationErrorHolidayTo" , true);
                    //component.set("v.applyLeave.To_Date__c",null);
                }
                
            }
            console.log('object',objectData);
            
        });
        $A.enqueueAction(action,false);
        component.set("v.dateValidationErrorHolidayFrom" , false);
        component.set("v.dateValidationErrorHolidayTo" , false);
    },
    onCancel : function (component, event, helper) {
        var urlEvent = $A.get("e.force:navigateToURL");  
        urlEvent.setParams({
            "url": "/s/work-from-home"
        });
        urlEvent.fire();   
    }
    
})