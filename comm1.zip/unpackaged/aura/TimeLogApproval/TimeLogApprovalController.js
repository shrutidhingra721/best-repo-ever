({
    doInit : function(component, event, helper) {
        component.set("v.showSpinner", true);
        component.set("v.bShowModal", false);
        component.set("v.noRecordPage",false);
        
        component.set('v.columns', [
            {
                label: 'View',
                type: 'button-icon',
                initialWidth: 75,
                typeAttributes: {
                    iconName: 'action:preview',
                    title: 'Preview',
                    variant: 'border-filled',
                    alternativeText: 'View'}
            },
            
            {label: 'Timesheet Name', fieldName: 'Name', type: 'Text',sortable:true},
            {label: 'Employee', fieldName: 'OwnerId', type: 'User',sortable:true},
            {label: 'Status', fieldName: 'Status__c', type: 'picklist',sortable:true},
            {label: 'Submitted Hours', fieldName: 'Total_Week_Hours__c', type: 'number',cellAttributes: { alignment: 'left'},sortable: true }           
        ]);
        helper.getTimeLogs(component, helper);
        component.set("v.showSpinner", false);
        
        
    },
    
    updateSelectedText: function (component, event,helper) {
        var selectedRows = event.getParam('selectedRows');
        for(var i=0;i<selectedRows.length;i++){
            if(selectedRows[i].Status__c=='Approved'|| selectedRows[i].Status__c=='Rejected' ){
                component.set('v.disableButtons',true);
            }
            else{
                component.set('v.disableButtons',false);
            }
        }
        component.set('v.selectedRowsCount', selectedRows.length);
        
        var setRows=[];
        for(var i = 0; i < selectedRows.length; i++){
            setRows.push(selectedRows[i].Id);
            
        }
        component.set('v.selectedRecords', setRows);        
    },
    
    approveRecords: function (component, event, helper) {
        if(component.get("v.selectedRowsCount") > 0){
            var action = component.get("c.approveTimeLogRecord");
            action.setParams({
                timeLogRecord : component.get("v.selectedRecords"),
                
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    var res = response.getReturnValue();
                    
                    this.showSuccess(component, event, helper);
                    var act = component.get("c.doInit");
                    $A.enqueueAction(act);                    
                }
            });
            $A.enqueueAction(action);
        }
        else{
            alert('Please select atleast one timelog to reject');
        }
    },
   
    rejectRecord: function (component, event, helper) {
        if(component.get("v.selectedRowsCount") > 0){
            var action = component.get("c.rejectTimeLogRecord");          
            action.setParams({
                timeLogRecord : component.get("v.selectedRecords"),
                
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                   var act = component.get("c.doInit");
                    $A.enqueueAction(act);
                }
            });
            $A.enqueueAction(action);
        }
        else{
            alert('Please select atleast one timelog to reject');
        }
        
    },
    approveSingleRecord: function (component, event, helper) {        
        var action = component.get("c.approveSingleTimeLogRecord");        
        action.setParams({
            singleTimeLogRecord : component.get("v.rowId"),
            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set("v.bShowModal", true);               
                var act = component.get("c.doInit");             
                $A.enqueueAction(act);
            }
        });
        $A.enqueueAction(action);
    },
    
    rejectSingleRecord: function (component, event, helper) {        
        var action = component.get("c.rejectSingleTimeLogRecord");
        action.setParams({
            singleTimeLogRecord : component.get("v.rowId"),            
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set("v.bShowModal", true);
                var act = component.get("c.doInit");                
                $A.enqueueAction(act);
            }
        });
        $A.enqueueAction(action);        
    },
    
    handleNext : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber+1);
        var selectRecord = component.get("v.rowId");
        console.log("in next last "+selectRecord);
        helper.buildDataTable(component, helper);
        var row = component.get("v.rowNumberOffset");
        component.set("v.rowNumberOffset", row+10);
    },
    
    handlePrev : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber-1);
        helper.buildDataTable(component, helper);
        var row = component.get("v.rowNumberOffset");
        component.set("v.rowNumberOffset", row-10);
    },
    
    handleRowAction:function(component, event, helper) {
        var action = component.get("c.getAllTimeLogEntries");
        var row = event.getParam('row');
        component.set('v.selectedRow', row); 
        component.set('v.rowId', row.Id);         
        component.set('v.entryColumns', [
            
            {label: 'Assignment', fieldName: 'Assignment__c', type: 'Text',cellAttributes: { alignment: 'left'}},
            {label: 'Sun Hours', fieldName: 'Sun_Hours__c', type: 'number',cellAttributes: { alignment: 'left'}},
            {label: 'Mon Hours', fieldName: 'Mon_Hours__c', type: 'number',cellAttributes: { alignment: 'left'}},
            {label: 'Tue Hours', fieldName: 'Tue_Hours__c', type: 'number',cellAttributes: { alignment: 'left'}},
            {label: 'Wed Hours', fieldName: 'Wed_Hours__c', type: 'number',cellAttributes: { alignment: 'left'}},
            {label: 'Thu Hours', fieldName: 'Thur_Hours__c', type: 'number',cellAttributes: { alignment: 'left'}},
            {label: 'Fri Hours', fieldName: 'Fri_Hours__c', type: 'number',cellAttributes: { alignment: 'left'}},
            {label: 'Sat Hours', fieldName: 'Sat_Hours__c', type: 'number',cellAttributes: { alignment: 'left'}},
            {label: 'Total Hours', fieldName: 'Total_Hours_Log_Entry__c', type: 'number',cellAttributes: { alignment: 'left'}}
            
        ]);
        
        action.setParams({
            timeLogId : component.get("v.rowId"),
            
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {                
                var rows = response.getReturnValue();                
                for (var i = 0; i < rows.length; i++) {
                    var row = rows[i];
                    if(row.Assignment__c) {
                        row.Assignment__c = row.Assignment__r.Name;
                    }
                }
                component.set('v.timeLogEntriesList', response.getReturnValue());                
                component.set("v.bShowModal", true);
            }
        });        
        $A.enqueueAction(action);        
    },
    closeModal:function(component, event, helper) {
        component.set("v.bShowModal", false);
    }    
    
})