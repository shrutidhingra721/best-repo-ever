({
    myAction : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var action = component.get("c.getContactList");
        component.set("v.Columns", [
            {label:"First Name", fieldName:"FirstName", type:"text"},
            {label:"Last Name", fieldName:"LastName", type:"text"},
            {label:"Phone", fieldName:"Phone", type:"phone"},
            {label:"Email", fieldName:"Email", type:"Email"},
            {label:"Title_Role__c", fieldName:"Title_Role__c", type:"Title_Role__c"},
        ]);
        
        action.setCallback(this, function(data) {
            if(data.getState() == 'SUCCESS'){
                alert(JSON.stringify(data.getReturnValue()));
                component.set("v.ContactsList", data.getReturnValue());
            }
        });
        $A.enqueueAction(action);
        
        
    }
})