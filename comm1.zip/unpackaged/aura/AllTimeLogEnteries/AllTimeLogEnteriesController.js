({
	doInit : function(component, event, helper) {
		var userId = $A.get("$SObjectType.CurrentUser.Id");
        
        component.set('v.columns', [
            
            {label: 'Time Log Name', fieldName: 'Name', type: 'Text'},
            {label: 'Total Week Hours', fieldName: 'Total_Week_Hours__c', type: 'number'}
            ]);
        
        var action = component.get("c.getAllTimeLogForCurrentUser");
        action.setParams({
            currentUserId : userId
        })
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set('v.timelogList', res);
            }
        });
        $A.enqueueAction(action);
	}
})