({
    myAction : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var action = component.get("c.getContacts");
        action.setParams({
            "recordId": recordId,
        });
        action.setCallback(this, function(data) {
            if(data.getState() == 'SUCCESS'){
                 alert(JSON.stringify(data.getReturnValue()));
                component.set("v.Contacts", data.getReturnValue());
            }
        });
        $A.enqueueAction(action);
        
        
    }
})