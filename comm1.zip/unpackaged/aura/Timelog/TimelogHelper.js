({
    setStartAndEndDates : function(component,event,weekValue) {
        var completeUrl = window.location.href;
        var indexOfWeek = completeUrl.search('week');
        var currentWeekDate = completeUrl.substring(indexOfWeek + 5);
        var words = currentWeekDate.split('-');
        var urlStringStartDate = words[0]+' '+words[1]+' '+words[2]+' '+words[3];
        
        component.set('v.mapOfDates', '');
        var currentDate = component.get("v.fixCurrentDate");
        var stringFixedCurrentDate = currentDate.toDateString();
        var d;
        var flag = component.get("v.flag");
        if(stringFixedCurrentDate != urlStringStartDate && flag == false && indexOfWeek > 0){
            d = new Date(urlStringStartDate);
            component.set('v.flag', true);
        } else{
            d = component.get("v.fixCurrentDate");
        }
        var getresult = new Date(d);
        
        if(weekValue == 'Previous'){
            getresult.setDate(getresult.getDate() - 7);
            d = getresult;
            component.set("v.fixCurrentDate",getresult);
        }
        if(weekValue == 'Next'){
            getresult.setDate(getresult.getDate() + 7);
            d = getresult;
            component.set("v.fixCurrentDate",getresult);
        }
        
        var today = d.toDateString();
        var day = d.getDay();
        
        var result = new Date(d);
        result.setDate(result.getDate() - day);
        component.set("v.wStartDate",result);
        var startdate = result.toDateString();
        component.set("v.weekStartDate", startdate);
        
        var resultend = new Date(d);
        resultend.setDate(resultend.getDate() + (6-day));
        component.set("v.wEndDate",resultend);
        var enddate = resultend.toDateString();
        component.set("v.weekEndDate",enddate);
        var mapOfDates = component.get('v.mapOfDates');
        var datesToUse =[];
        var daysToUse =[];
        var setDateHours = component.get("v.setDateHours");
        for (var i = 0; i < 7; i++) {
            var resuld = new Date(component.get('v.weekStartDate'));
            resuld.setDate(resuld.getDate() + (i));
            var strResuld = resuld.toDateString();
            daysToUse[i] = strResuld.substring(0,3);
            datesToUse[i] = strResuld.substring(4);
            setDateHours[strResuld.substring(4)] = 0;
        }
        var x = JSON.stringify(setDateHours);
        var y= setDateHours;
        console.log('setDateHours'+JSON.stringify(setDateHours));
        component.set("v.fixCurrentDate",getresult);
        component.set('v.mapOfDays',daysToUse);
        component.set('v.mapOfDates', datesToUse);
        if(completeUrl.includes('detail')){
            component.set("v.sppiner", true);
            location.reload();
        }
    },
    
    getPreviousWeekTimeLogEnrties:function(component,event,helper){
        var WSD = component.get("v.weekStartDate");
        var WED = component.get("v.weekEndDate");
        
        var d = new Date(WSD);
        var d1 = new Date(WED);
        d.setDate(d.getDate() - 7);
        d1.setDate(d1.getDate() - 7);
        var startdate = d.toDateString();
        var enddate = d1.toDateString();
        var TLName = 'Week' +' - '+ '(' +startdate+ ' - ' +enddate+ ')';
        var action = component.get("c.getTimeLogForPreviousWeek");
        action.setParams({TLName : TLName});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                
                component.set('v.listofTLEForPreviousWeek', res);
                console.log(component.get('v.listofTLEForPreviousWeek'));
                var TLEL = [];
                TLEL = component.get('v.listofTLEForPreviousWeek');
                var x;
                var Count = 1;
                for(x in TLEL){
                    var a = {'sobjectType' : 'Time_Log_Entries__c', 'Assignment__c' : '', 'Sun_Hours__c' : '', 'Mon_Hours__c' : '', 'Tue_Hours__c' : '', 'Wed_Hours__c' : '', 'Thur_Hours__c' : '', 'Fri_Hours__c' : '', 'Sat_Hours__c' : '',};
                    a.Assignment__c = TLEL[x].Assignment__c;
                    a.Sun_Hours__c = TLEL[x].Sun_Hours__c;
                    a.Mon_Hours__c = TLEL[x].Mon_Hours__c;
                    a.Tue_Hours__c = TLEL[x].Tue_Hours__c;
                    a.Wed_Hours__c = TLEL[x].Wed_Hours__c;
                    a.Thur_Hours__c = TLEL[x].Thur_Hours__c;
                    a.Fri_Hours__c = TLEL[x].Fri_Hours__c;
                    a.Sat_Hours__c = TLEL[x].Sat_Hours__c;
                    component.set('v.TimeLogEntry'+Count,a);
                    Count++;
                }
                component.set("v.sppiner", false);
                
                this.addFR1(component,event,helper);
            }else {
                component.set("v.sppiner", false);
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                    errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);	
    }, 
    
    getExistingTimeLogEnrty:function(component,event,helper){
        component.set("v.sppiner", true);
        var WSD = component.get("v.weekStartDate");
        var WED = component.get("v.weekEndDate");
        var TLName = 'Week' +' - '+ '(' +WSD+ ' - ' +WED+ ')';
        
        var action = component.get("c.getTimeLog");
        action.setParams({TLName : TLName});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set('v.listofTLE', res);
                var TLEL = [];
                TLEL = component.get('v.listofTLE');
                var x;
                var Count = 1;
                for(x in TLEL){
                    component.set('v.TimeLogEntry'+Count,TLEL[x]);
                    Count++;
                }
                this.addFR1(component,event,helper);
            }else {
                component.set("v.sppiner", false);
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                    errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);	
    }, 
    handlePreviousWeek1 : function(component,event,weekValue) {
        this.setStartAndEndDates(component,event,weekValue);
        this.getExistingTimeLogEnrty(component,event);
        this.disableTimeLog(component,event);
    },
    handleNextWeek1 : function(component,event,weekValue) {
        this.setStartAndEndDates(component,event,weekValue);
        this.getExistingTimeLogEnrty(component,event);
        this.disableTimeLog(component,event);
    }, 
    reset:function(component,event,weekValue){
        component.set("v.sppiner", true);
        component.set("v.TimeLogEntry1",{
            'sobjectType' : 'Time_Log_Entries__c',
            'Assignment__c' : '',
            'Sun_Hours__c' : '',
            'Mon_Hours__c' : '',
            'Tue_Hours__c' : '',
            'Wed_Hours__c' : '',
            'Thur_Hours__c' : '',
            'Fri_Hours__c' : '',
            'Sat_Hours__c' : '',
        });
        component.set("v.TimeLogEntry2",{
            'sobjectType' : 'Time_Log_Entries__c',
            'Assignment__c' : '',
            'Sun_Hours__c' : '',
            'Mon_Hours__c' : '',
            'Tue_Hours__c' : '',
            'Wed_Hours__c' : '',
            'Thur_Hours__c' : '',
            'Fri_Hours__c' : '',
            'Sat_Hours__c' : '',
        });
        component.set("v.TimeLogEntry3",{
            'sobjectType' : 'Time_Log_Entries__c',
            'Assignment__c' : '',
            'Sun_Hours__c' : '',
            'Mon_Hours__c' : '',
            'Tue_Hours__c' : '',
            'Wed_Hours__c' : '',
            'Thur_Hours__c' : '',
            'Fri_Hours__c' : '',
            'Sat_Hours__c' : '',
        });
        component.set("v.TimeLogEntry4",{
            'sobjectType' : 'Time_Log_Entries__c',
            'Assignment__c' : '',
            'Sun_Hours__c' : '',
            'Mon_Hours__c' : '',
            'Tue_Hours__c' : '',
            'Wed_Hours__c' : '',
            'Thur_Hours__c' : '',
            'Fri_Hours__c' : '',
            'Sat_Hours__c' : '',
        });
        component.set("v.TimeLogEntry5",{
            'sobjectType' : 'Time_Log_Entries__c',
            'Assignment__c' : '',
            'Sun_Hours__c' : '',
            'Mon_Hours__c' : '',
            'Tue_Hours__c' : '',
            'Wed_Hours__c' : '',
            'Thur_Hours__c' : '',
            'Fri_Hours__c' : '',
            'Sat_Hours__c' : '',
        });
        component.set("v.TotR1","0");
        component.set("v.TotR2","0");
        component.set("v.TotR3","0");
        component.set("v.TotR4","0");
        component.set("v.TotR5","0");
        component.set("v.Totc1","0");
        component.set("v.Totc2","0");
        component.set("v.Totc3","0");
        component.set("v.Totc4","0");
        component.set("v.Totc5","0");
        component.set("v.Totc6","0");
        component.set("v.Totc7","0");
        component.set("v.Totc8","0");
        if(weekValue == 'Previous'){
            this.handlePreviousWeek1(component,event,weekValue);
        }
        if(weekValue == 'Next'){
            this.handleNextWeek1(component,event,weekValue);
        }
    },
    disableTimeLog : function(component,event,helper){
        component.set("v.sppiner", true);
        var WSD = component.get("v.weekStartDate");
        var WED = component.get("v.weekEndDate");
        var TLName = 'Week' +' - '+ '(' +WSD+ ' - ' +WED+ ')';
        var action = component.get("c.getApprovalStatus");
        action.setParams({TLName : TLName});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set('v.listofTL', res);
                var TLL = [];
                TLL = component.get('v.listofTL');
                if(TLL.length > 0){
                    component.set('v.disablefields',true);
                }
                else{
                    component.set('v.disablefields',false);
                }
                component.set("v.sppiner", false);
            }else {
                var errors = response.getError();
                if (errors) {
                    component.set("v.sppiner", false);
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +  errors[0].message);
                    }
                } else {
                    component.set("v.sppiner", false);
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    addFR1 :function(component,event,helper) {
        component.set("v.sppiner", true);
        var TotFR = 0;
        var txt1 = component.find('txt1').get("v.value") || 0;
        var txt2 = component.find('txt2').get("v.value") || 0;
        var txt3 = component.find('txt3').get("v.value") || 0;
        var txt4 = component.find('txt4').get("v.value") || 0;
        var txt5 = component.find('txt5').get("v.value") || 0;
        var txt6 = component.find('txt6').get("v.value") || 0;
        var txt7 = component.find('txt7').get("v.value") || 0;
        var TotFR1 = Number(txt1)+ Number(txt2)+ Number(txt3)+ Number(txt4)+ Number(txt5)+ Number(txt6)+ Number(txt7);
        component.set("v.TotR1",TotFR1);
        var txt8 = component.find('txt8').get("v.value") || 0;
        var txt9 = component.find('txt9').get("v.value") || 0;
        var txt10 = component.find('txt10').get("v.value") || 0;
        var txt11 = component.find('txt11').get("v.value") || 0;
        var txt12 = component.find('txt12').get("v.value") || 0;
        var txt13 = component.find('txt13').get("v.value") || 0;
        var txt14 = component.find('txt14').get("v.value") || 0;
        var TotFR2 =  Number(txt8)+ Number(txt9)+ Number(txt10)+ Number(txt11)+ Number(txt12)+ Number(txt13)+ Number(txt14);
        component.set("v.TotR2",TotFR2);
        var txt15 = component.find('txt15').get("v.value") || 0;
        var txt16 = component.find('txt16').get("v.value") || 0;
        var txt17 = component.find('txt17').get("v.value") || 0;
        var txt18 = component.find('txt18').get("v.value") || 0;
        var txt19 = component.find('txt19').get("v.value") || 0;
        var txt20 = component.find('txt20').get("v.value") || 0;
        var txt21 = component.find('txt21').get("v.value") || 0;
        var TotFR3 =  Number(txt15)+ Number(txt16)+ Number(txt17)+ Number(txt18)+ Number(txt19)+ Number(txt20)+ Number(txt21);
        component.set("v.TotR3",TotFR3);
        var txt22 = component.find('txt22').get("v.value") || 0;
        var txt23 = component.find('txt23').get("v.value") || 0;
        var txt24 = component.find('txt24').get("v.value") || 0;
        var txt25 = component.find('txt25').get("v.value") || 0;
        var txt26 = component.find('txt26').get("v.value") || 0;
        var txt27 = component.find('txt27').get("v.value") || 0;
        var txt28 = component.find('txt28').get("v.value") || 0;
        var TotFR4 =  Number(txt22)+ Number(txt23)+ Number(txt24)+ Number(txt25)+ Number(txt26)+ Number(txt27)+ Number(txt28);
        component.set("v.TotR4",TotFR4);
        var txt29 = component.find('txt29').get("v.value") || 0;
        var txt30 = component.find('txt30').get("v.value") || 0;
        var txt31 = component.find('txt31').get("v.value") || 0;
        var txt32 = component.find('txt32').get("v.value") || 0;
        var txt33 = component.find('txt33').get("v.value") || 0;
        var txt34 = component.find('txt34').get("v.value") || 0;
        var txt35 = component.find('txt35').get("v.value") || 0;
        var TotFR5 = Number(txt29)+ Number(txt30)+ Number(txt31)+ Number(txt32)+ Number(txt33)+ Number(txt34)+ Number(txt35);
        component.set("v.TotR5",TotFR5);
        var TotC1 = Number(txt1)+Number(txt8)+Number(txt15)+Number(txt22)+Number(txt29);
        var TotC2 = Number(txt2)+Number(txt9)+Number(txt16)+Number(txt23)+Number(txt30);
        var TotC3 = Number(txt3)+Number(txt10)+Number(txt17)+Number(txt24)+Number(txt31);
        var TotC4 = Number(txt4)+Number(txt11)+Number(txt18)+Number(txt25)+Number(txt32);
        var TotC5 = Number(txt5)+Number(txt12)+Number(txt19)+Number(txt26)+Number(txt33);
        var TotC6 = Number(txt6)+Number(txt13)+Number(txt20)+Number(txt27)+Number(txt34);
        var TotC7 = Number(txt7)+Number(txt14)+Number(txt21)+Number(txt28)+Number(txt35);
        var TotC8 = Number(TotFR1)+Number(TotFR2)+Number(TotFR3)+Number(TotFR4)+Number(TotFR5);
        component.set("v.Totc1",TotC1);
        component.set("v.Totc2",TotC2);
        component.set("v.Totc3",TotC3);
        component.set("v.Totc4",TotC4);
        component.set("v.Totc5",TotC5);
        component.set("v.Totc6",TotC6);
        component.set("v.Totc7",TotC7);
        component.set("v.Totc8",TotC8);
        console.log(component.get("v.TimeLogEntry1"));
        component.set("v.sppiner", false);
    },
    
    createTimeLog :function(component,event,helper){
        
        var a = component.get("v.TimeLogEntry1");
        var b = component.get("v.TimeLogEntry2");
        var c = component.get("v.TimeLogEntry3");
        var d = component.get("v.TimeLogEntry4");
        var e = component.get("v.TimeLogEntry5");
        
        var allEnteries = [a,b,c,d,e];
        var oneTimeEnteryData = {};
        var errorFlag = false;
        var listOfAssignments=[];  
        for(var i=0; i < allEnteries.length; i++){
            
            listOfAssignments.push(allEnteries[i].Assignment__c);
        }
        var assignmentIsBlank = true;
        var timeLogEntryIsBlank = true;
        for(var i=0; i<listOfAssignments.length; i++){
            if(listOfAssignments[i] != '' && listOfAssignments[i] != null && listOfAssignments[i] != undefined){
                assignmentIsBlank = false;
               
                var timeLogEntryValues = Object.entries(allEnteries[i]);
                var checkIstimeLogEntryRowBlank = true;
                for(var j=0; j < timeLogEntryValues.length; j++){
                    if(timeLogEntryValues[j][1] != null && timeLogEntryValues[j][1] != '' && timeLogEntryValues[j][1] != undefined && timeLogEntryValues[j][0] != 'sobjectType' && timeLogEntryValues[j][0] != 'Assignment__c'){
                        timeLogEntryIsBlank = false;
                        checkIstimeLogEntryRowBlank = false;
                        
                    }
                    if(checkIstimeLogEntryRowBlank){
                        timeLogEntryIsBlank = true;
                        
                    }
                }
                
            }else{
                if(assignmentIsBlank){ 
                   
                    this.showErrorAssignment(component,event,helper);
                    component.set("v.sppiner", false);
                }else{
                    
                    var timeLogEntryValues = Object.entries(allEnteries[i]);
                    var checkIstimeLogEntryRowNotBlank = false;
                    for(var j=0; j < timeLogEntryValues.length; j++){
                        if(timeLogEntryValues[j][1] != null && timeLogEntryValues[j][1] != '' && timeLogEntryValues[j][1] != undefined && timeLogEntryValues[j][0] != 'sobjectType' && timeLogEntryValues[j][0] != 'Assignment__c'){
                            
                            checkIstimeLogEntryRowNotBlank = true;
                            
                        }
                        if(checkIstimeLogEntryRowNotBlank){
                            this.showErrorAssignment(component,event,helper);
                            
                            component.set("v.sppiner", false);
                        }
                    }
                }
            }
        }
        var isSameAssignment = false;
        for(var i=0; i<listOfAssignments.length; i++){
            for(var j=0; j<listOfAssignments.length; j++){
                if(i != j && listOfAssignments[i] == listOfAssignments[j] && listOfAssignments[i] != null && listOfAssignments[i] != '' && listOfAssignments[i] != undefined && listOfAssignments[j] != null && listOfAssignments[j] != '' && listOfAssignments[j] != undefined){
                    isSameAssignment = true;
                    
                }
            }
        } 
        console.log(component.get("v.TimeLogEntry1"));
        component.set("v.sppiner", false);  
        if(assignmentIsBlank == false && timeLogEntryIsBlank == false && isSameAssignment == false){
            console.log('1 '+listOfAssignments);
            console.log('2 '+component.get("v.TimeLogEntry1"));
            console.log('3 '+component.get("v.TimeLogEntry2"));
            console.log('4 '+component.get("v.TimeLogEntry3"));
            console.log('5 '+component.get("v.TimeLogEntry4"));
            console.log('6 '+component.get("v.TimeLogEntry5"));
            console.log('7 '+component.get("v.weekStartDate"));
            console.log('8 '+component.get("v.weekEndDate"));
            console.log('9 '+component.get("v.oUser"));
            console.log('10 '+component.get("v.wStartDate"));
            console.log('11 '+component.get("v.wEndDate"));
            var action = component.get("c.saveTimeLog");
            action.setParams({
                listOfAssignments: listOfAssignments,
                TLE1 : component.get("v.TimeLogEntry1"),
                TLE2 : component.get("v.TimeLogEntry2"),
                TLE3 : component.get("v.TimeLogEntry3"),
                TLE4 : component.get("v.TimeLogEntry4"),
                TLE5 : component.get("v.TimeLogEntry5"),
                WSD : component.get("v.weekStartDate"),
                WED : component.get("v.weekEndDate"),
                usr : component.get("v.oUser"),
                wStartDate : component.get("v.wStartDate"),
                wEndDate : component.get("v.wEndDate")
            })
            action.setCallback(this, function(response) {
                var state = response.getState();
                console.log('12 '+state);
                if (state === "SUCCESS") {
                    
                    var res = response.getReturnValue();
                    this.showSuccess(component, event, helper);
                    component.set("v.sppiner", false);
                }else {
                    
                    component.set("v.sppiner", false);
                    var errors = response.getError();
                    if (errors){
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " + errors[0].message);
                        }
                    }else {
                        console.log("Unknown error");
                    }
                }
            });
            $A.enqueueAction(action);
        }else{
            if(assignmentIsBlank == false && timeLogEntryIsBlank != false && isSameAssignment == false){
                this.showErrorHrs(component,event,helper);
                component.set("v.sppiner", false);
            }
            if(isSameAssignment == true){
                this.showErrorSameAssignment(component,event,helper);
                component.set("v.sppiner", false);
            }
            
        }
    },
    deleteOnReset : function(component,event,helper){
        component.set("v.sppiner", true);
        var WSD = component.get("v.weekStartDate");
        var WED = component.get("v.weekEndDate");
        var TLName = 'Week' +' - '+ '(' +WSD+ ' - ' +WED+ ')';
        var action = component.get("c.deleteResetValues");
        action.setParams({TLName : TLName});
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.sppiner", false);
                var res = response.getReturnValue();
            }else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set("v.sppiner", false);
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    component.set("v.sppiner", false);
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);	
    },
    showErrorHrs : function(component,event,helper) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : 'Error',
            message:'Mention Hrs for the selected assignment.',
            duration:' 5000',
            key: 'info_alt',
            type: 'error',
            mode: 'pester'
        });
        toastEvent.fire();
    },
    showErrorAssignment : function(component,event,helper) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : 'Error',
            message:'Assignment cannot be empty.',
            duration:' 5000',
            key: 'info_alt',
            type: 'error',
            mode: 'pester'
        });
        toastEvent.fire();
    },
    showErrorSameAssignment : function(component,event,helper) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : 'Error',
            message:'Select different Assignment for each row.',
            duration:' 5000',
            key: 'info_alt',
            type: 'error',
            mode: 'pester'
        });
        toastEvent.fire();
    },
    showSuccess : function(component, event, helper) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : 'Success',
            message: 'Record created successfully.',
            duration:' 5000',
            key: 'info_alt',
            type: 'success',
            mode: 'pester'
        });
        toastEvent.fire();
    },
    showSuccess1 : function(component, event, helper) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : 'Success',
            message: 'Record Submitted successfully.',
            duration:' 5000',
            key: 'info_alt',
            type: 'success',
            mode: 'pester'
        });
        toastEvent.fire();
    },
})