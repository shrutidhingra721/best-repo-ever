({
    
      getManagerList : function(component, event, helper) {
        // Helper function - fetchContacts called for interaction with server
                
                helper.fetchManager(component, event, helper);
        },
    
  // Function called on initial page loading to get contact list from server
        getManagerChildList : function(component, event, helper) {
        // Helper function - fetchContacts called for interaction with server
                
                helper.fetchUsers(component, event, helper);
        },
   
    
    getUserChildList : function(component, event, helper) {
        // Helper function - fetchContacts called for interaction with server
                
                helper.getUserChild(component, event, helper);
        },
    
    getUserGrandList : function(component, event, helper) {
        // Helper function - fetchContacts called for interaction with server
                
                helper.getUserGrand(component, event, helper);
        },
    })