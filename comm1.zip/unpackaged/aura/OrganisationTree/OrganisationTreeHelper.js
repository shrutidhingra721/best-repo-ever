({
    
    // Function to fetch data from server called in initial loading of page
    fetchManager : function(component, event, helper) {
        // Assign server method to action variable
        var action = component.get("c.fetchManagerDetail");
        
        
        // Callback function to get the response
        action.setCallback(this, function(response) {
            // Getting the response state
            var state = response.getState();
            // Check if response state is success
            if(state === 'SUCCESS') {
                // Getting the list of contacts from response and storing in js variable
                var Mgr = response.getReturnValue();
                // Set the list attribute in component with the value returned by function
                component.set("v.allManagerList",Mgr);
                
            }
            else {
                // Show an alert if the state is incomplete or error
                alert('Error in getting data');
            }
        });
        // Adding the action variable to the global action queue
        $A.enqueueAction(action);
    }, 
    
    
    // Function to fetch data from server called in initial loading of page
    fetchUsers : function(component, event, helper) {
        // Assign server method to action variable
        var action = component.get("c.fetchUserDetail");
        
        
        // Callback function to get the response
        action.setCallback(this, function(response) {
            // Getting the response state
            var state = response.getState();
            // Check if response state is success
            if(state === 'SUCCESS') {
                // Getting the list of contacts from response and storing in js variable
                var allUser = response.getReturnValue();
                // Set the list attribute in component with the value returned by function
                component.set("v.allUsersList",allUser);
                
            }
            else {
                // Show an alert if the state is incomplete or error
                alert('Error in getting data');
            }
        });
        // Adding the action variable to the global action queue
        $A.enqueueAction(action);
    }, 
    
    
    getUserChild : function(component, event, helper) {
        var action = component.get("c.fetchUserDetails");
        action.setCallback(this, function(response) {
            // Getting the response state
            var state = response.getState();
            // Check if response state is success
            if(state === 'SUCCESS') {
                // Getting the list of contacts from response and storing in js variable
                var allChdUsr = response.getReturnValue();
                // Set the list attribute in component with the value returned by function
                component.set("v.AllChildList",allChdUsr);
                
            }
            else {
                // Show an alert if the state is incomplete or error
                alert('Error in getting data');
            }
        });
        // Adding the action variable to the global action queue
        $A.enqueueAction(action);
    },
    
    
    getUserGrand : function(component, event, helper) {
        var action = component.get("c.fetchUserDetailss");
        action.setCallback(this, function(response) {
            // Getting the response state
            var state = response.getState();
            // Check if response state is success
            if(state === 'SUCCESS') {
                // Getting the list of contacts from response and storing in js variable
                var allGrdChdUsr = response.getReturnValue();
                // Set the list attribute in component with the value returned by function
                component.set("v.AllGrandChildList",allGrdChdUsr);
                
            }
            else {
                // Show an alert if the state is incomplete or error
                alert('Error in getting data');
            }
        });
        // Adding the action variable to the global action queue
        $A.enqueueAction(action);
        
    }
    
    
    
    
    
    
})