({
    getUserlist : function(component) {
        var action = component.get("c.getUserlist");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.newleave", response.getReturnValue());
                alert("helper");
            }
            else {
                console.log("Failed with state: " + state);
            }
        });
        $A.enqueueAction(action);
    } ,
    dateUpdate : function(component, event, helper) {
        
        var c = component.get("v.applyLeave.From_Date__c");
        var b = component.get("v.applyLeave.To_Date__c");
        var a = new Date(c);
        var e = new Date(b);
        var days = new Array(7);
        days[0] = "Sunday";
        days[1] = "Monday";
        days[2] = "Tuesday";
        days[3] = "Wednesday";
        days[4] = "Thursday";
        days[5] = "Friday";
        days[6] = "Saturday";
        var r = days[a.getDay()];
        var s = days[e.getDay()];
        
        var today = new Date();        
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();   
        if(dd < 10){
            dd = '0' + dd;
        }  
        if(mm < 10){
            mm = '0' + mm;
        }
        
        var todayFormattedDate = yyyy+'-'+mm+'-'+dd;
        if (r=="Saturday" || r=="Sunday" || s=="Saturday" || s=="Sunday"){
            // alert("Now");
            component.set("v.dateValidationError" , true);
            //component.set("v.applyLeave.From_Date__c",null);
           // component.set("v.applyLeave.To_Date__c",null);
        }
        else if(component.get("v.applyLeave.From_Date__c") != '' && component.get("v.applyLeave.From_Date__c") < todayFormattedDate){
            component.set("v.dateValidationError" , flase);
        }else if(component.get("v.applyLeave.To_Date__c") != '' && component.get("v.applyLeave.To_Date__c") < component.get("v.applyLeave.From_Date__c")){
            component.set("v.dateValidationError" , true);
        }else{
            component.set("v.dateValidationError" , false);
        }
    }
    
})