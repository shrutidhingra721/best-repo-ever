({   
      
  approveRecords: function (component, event, helper) {
        if(component.get("v.selectedRowsCount") > 0){
            var action = component.get("c.approveLeaveRecord");
            
            action.setParams({
                LeaveRecord : component.get("v.selectedRecords"),
                
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    
                    var res = response.getReturnValue();                  
                    this.showSuccess(component, event, helper);                   
                    var act = component.get("c.doInit");
                    $A.enqueueAction(act);                   
                }
            });
            $A.enqueueAction(action);           
        }
        else{
            alert('Please select atleast one leave to Approve');
        }
    },
    
    showSuccess : function(component, event, helper) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            
            duration: 5000 ,
            key: 'info_alt',
            type: 'success',
            mode: 'pester',
            "title" : 'Success',
            "message": 'Record Approved successfully.'
            
        });
        toastEvent.fire();
    },
    showReject : function(component, event, helper) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            
            duration : 5000,
            key: 'info_alt',
            type: 'success',
            mode: 'pester',
            "title" : 'Success',
            "message": 'Record Rejected successfully.'
                
        });
        toastEvent.fire();
    },
    
	  getLeaveData : function(component, helper) {
      
        var action = component.get("c.getAllPendingleaves");      
        action.setCallback(this,function(response) {
            var state = response.getState();
            console.log('state '+state);
            if (state === "SUCCESS") {
                var resultData = response.getReturnValue();
                component.set("v.totalPages", Math.ceil(response.getReturnValue().length/component.get("v.pageSize")));
                component.set("v.allData", response.getReturnValue());
                component.set("v.currentPageNumber",1);
                var rows = response.getReturnValue();
                 console.log('rows '+rows);
                console.log('rows.length '+rows.length);
                console.log('resultData '+resultData);
                if(rows.length>0)
                {
                     component.get("v.noRecordPage", false);
                    for (var i = 0; i < rows.length; i++) {
                        var row = rows[i];
                        if(row.Owner) {
                            row.OwnerId = row.Owner.Name;
                        }                        
                    }
                }
                if(rows.length==0)
                {
                    component.set("v.noRecordPage", true);
                }
                helper.buildData(component, helper);                 
            }
            else{
                component.set("v.noRecordPage", true);
            }
        });
        $A.enqueueAction(action);
    },    
  
    buildData : function(component, helper) {
        var data = [];
        var pageNumber = component.get("v.currentPageNumber");
        var pageSize = component.get("v.pageSize");
        var allData = component.get("v.allData");
        var last = component.get("v.last");      
        var totalData = allData.length;
        var x = (pageNumber-1)*pageSize;
        var last;
        if(totalData < (pageNumber)*pageSize){
            last = totalData;
        }
        else{
            last = pageNumber*pageSize;    
        }
        component.set("v.next",last);
        //creating data-table data
        for(; x<(pageNumber)*pageSize; x++){
            if(allData[x]){
                data.push(allData[x]);
            }
        }
        component.set("v.leaveApprovalList", data);   
    }   
})