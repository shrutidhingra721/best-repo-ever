({
	setStartAndEndDates : function(component,event,weekValue) {
        var d=component.get("v.fixCurrentDate");
        var getresult = new Date(d);
        if(weekValue == 'Previous'){
            getresult.setDate(getresult.getDate() - 7);
            d = getresult;
            component.set("v.fixCurrentDate",getresult);
        }
        if(weekValue == 'Next'){
            getresult.setDate(getresult.getDate() + 7);
            d = getresult;
            component.set("v.fixCurrentDate",getresult);
        }
        
        var today = d.toDateString();
        var day = d.getDay();
        
        var result = new Date(d);
        result.setDate(result.getDate() - day);
        var startdate = result.toDateString();
        component.set("v.weekStartDate", startdate);
        
        var resultend = new Date(d);
        resultend.setDate(resultend.getDate() + (6-day));
        var enddate = resultend.toDateString();
        component.set("v.weekEndDate",enddate);
	}
})