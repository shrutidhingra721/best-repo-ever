({
 parentPress : function(cmp, event, helper) {
         
        var objChild = component.find('compB');
        alert("Method Called from Child " + objChild.get('v.subTabs'));
    }	    
})