({
   doInit: function(component, event, helper) {  
        var action = component.get('c.ContactId');  
         action.setCallback(this, function(response) {    
            var state = response.getState();  
            console.log(response);
            if (state === "SUCCESS") {
                component.set("v.recordId", response.getReturnValue());  
            }  
        });  
        $A.enqueueAction(action);
        
	},

    handleSubmit : function(component, event, helper) {
       
		console.log('handle handleSubmit');
	},
	handleSuccess : function(component, event, helper) {
		console.log('record updated successfully');
        
        
        component.set("v.showSpinner", false);
	},
	
})