({
	LeaveClick: function(component, event, helper) {
          var urlEvent = $A.get("e.force:navigateToURL");
       urlEvent.setParams({
           "url": "/leave"
       });
       urlEvent.fire();
		},
    
    wfhClick: function(component, event, helper)  {
     var urlEvent = $A.get("e.force:navigateToURL");
       urlEvent.setParams({
           "url": "/work-from-home"
       });
       urlEvent.fire();
}
})