({
    scriptsLoaded : function(component, event, helper) {
        
        $(document).ready(function(){ 
              $( "#datepickerId" ).datepicker({
                beforeShowDay: function(date){
                    var show = true;
                    var today = new Date();
                    if(date.getDay()==6||date.getDay()==0)
                    {show=false}
                    
                      else if(date > today){
                        return [true];
                    }
                    else{
                        return [false];
                    }
                    return [show];

                },
            });           
        });
    $(document).ready(function(){ 
          //Restrict past date selection in date picker  
            $( "#datepickerId" ).datepicker({
                beforeShowDay: function(date) {
                    var today = new Date();
                    if(date > today){
                        return [true];
                    }
                    else{
                        return [false];
                    }	 
                },
            });           
        });
       
    },
         
       getVal : function(component,event,helper){
        // to get selected date value using jQuery  
        var oDate = $('#datepickerId').val();
      
        alert(oDate);
        
        
    },
    holidaydisplay : function(component, event, helper) {
        //var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");
       //component.set('v.today', today);
      //alert(today);
		helper.displayholiday(component);
        
    }
})