({
	doInit2: function(component, event, helper) {  
        var action = component.get('c.GetSkill');  
        action.setCallback(this, function(response) {    
            var state = response.getState();  
            console.log(response);
            if (state === "SUCCESS") {
                var responseValue = response.getReturnValue();
                console.log(responseValue);
                component.set("v.skill", response.getReturnValue());  
            }  
        });  
        $A.enqueueAction(action);
        
    },
    addSkills: function(component, event, helper) {
        
        component.set("v.isEditPage",true);
    
      
    },
    
   
})