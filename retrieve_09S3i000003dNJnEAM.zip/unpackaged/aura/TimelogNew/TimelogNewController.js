({
    doInit : function(component, event, helper) {
        component.set("v.fixCurrentDate",new Date());
        var weekValue = 'Current';
        helper.setStartAndEndDates(component,event,weekValue);
    },
    handlePreviousWeek : function(component, event, helper) {
        var weekValue = 'Previous';
        helper.setStartAndEndDates(component,event,weekValue);
    },
    handleNextWeek : function(component, event, helper) {
        var weekValue = 'Next';
        helper.setStartAndEndDates(component,event,weekValue);
    },
})