({
    doInit: function(component, event, helper) {  
        var action = component.get('c.getEmployeeDetails');  
        action.setCallback(this, function(response) {    
            var state = response.getState();  
            console.log(response);
            if (state === "SUCCESS") {
                var responseValue = response.getReturnValue();
                console.log(responseValue);
                component.set("v.employee", response.getReturnValue());  
            }  
        });  
        $A.enqueueAction(action);
        
    },
    
   
    doInit1 : function(component, event, helper) {
        var action = component.get("c.fetchUserDetail");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set('v.oUser', res);
            }
            else if (state === "INCOMPLETE") {
                // do something
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " +
                                        errors[0].message);
                        }
                    } else {
                        console.log("Unknown error");
                    }
                }
        });
        $A.enqueueAction(action);
    },
    
     doInit2: function(component, event, helper) {  
        var action = component.get('c.ContactId');  
         action.setCallback(this, function(response) {    
            var state = response.getState();  
            console.log(response);
            if (state === "SUCCESS") {
                component.set("v.recordId", response.getReturnValue());  
            }  
        });  
        $A.enqueueAction(action);
        
	},
    
    onInit2: function(component,event,helper) {
        var action1 = component.get("c.getContactId")
        action1.setCallback(this, function(response) {    
            var state = response.getState();  
            console.log(response);
            if (state === "SUCCESS") {
                component.set("v.parentId", response.getReturnValue());  
            }  
        });  
        $A.enqueueAction(action1);
        var action = component.get("c.getProfilePicture");
        action.setParams({
            parentId:component.get("v.parentId"),
            
        });
        action.setCallback(this, function(a) {
            var attachment = a.getReturnValue();
            console.log(attachment);
            if (attachment && attachment.Id) {
                component.set("v.pictureSrc",'/servlet/servlet.FileDownload?file='
                             + attachment.Id);
            }
            alert(attachId);
        });
        $A.enqueueAction(action);  
        
    },
    
   onInit3: function(component, event, helper) {  
        var action = component.get('c.GetSkill');  
        action.setCallback(this, function(response) {    
            var state = response.getState();  
            console.log(response);
            if (state === "SUCCESS") {
                var responseValue = response.getReturnValue();
                console.log(responseValue);
                component.set("v.skill", response.getReturnValue());  
            }  
        });  
        $A.enqueueAction(action);
        
    },      
    onInit4: function(component, event, helper) {  
        var action = component.get('c.GetManager');  
        action.setCallback(this, function(response) {    
            var state = response.getState();  
            console.log(response);
            if (state === "SUCCESS") {
                var responseValue = response.getReturnValue();
                console.log('Manager'+responseValue);
                component.set("v.setmanager", response.getReturnValue());  
            }  
        });  
        $A.enqueueAction(action);
        
    },  
    openModel: function(component, event, helper) {
      // for Display Model,set the "isOpen" attribute to "true"
      component.set("v.isModalOpen", true);
   },
     closeModel: function(component, event, helper) {
      // Set isModalOpen attribute to false  
      component.set("v.isModalOpen", false);
   },
    handleUpload: function (cmp, event) {
        //Get the list of uploaded files
        var uploadedFiles = event.getParam("files");
         component.set("v.pictureSrc", uploadedFiles);
        //Show success message – with no of files uploaded
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "type" : "success",
            "message": uploadedFiles.length+" files has been uploaded successfully!"
        });
        toastEvent.fire();
        
        $A.get('e.force:refreshView').fire();
        
        //Close the action panel
        var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
    },
    
    
    handleSave: function(component, event, helper) {
        if (component.find("fuploader").get("v.files").length > 0) {
            helper.uploadHelper(component, event);
            component.set("v.pictureSrc", attachId);
        } else {
            alert('Please Select a Valid File');
        }
    },
    handleUploadFinished: function (cmp, event) {
        //Get the list of uploaded files
        var uploadedFiles = event.getParam("files");
        //Show success message – with no of files uploaded
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "type" : "success",
            "message": uploadedFiles.length+" files has been uploaded successfully!"
        });
        toastEvent.fire();
        
        
        $A.get('e.force:refreshView').fire();
        
        //Close the action panel
        var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
    },
    
    handleFilesChange: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        alert(fileName);
        component.set("v.fileName", fileName);
    },
    
    handleCancel: function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
    },
      handleOnSubmit : function(component, event, helper) {
          console.log("submitted");
          var toastEvent = $A.get("e.force:showToast");
    toastEvent.setParams({
        "title": "Success!",
        "message": "The record has been updated successfully."
    });
    toastEvent.fire();
         
    },
   
   OnSubmit : function(cmp, event, helper) {
         var toastEvent = $A.get("e.force:showToast");
    toastEvent.setParams({
        "title": "Success!",
        "message": "The record has been updated successfully."
    });
    toastEvent.fire();

    },
    OnSuccess : function(component, event, helper) {
        
    },
    
    navigateToOrgTree:function(component, event, helper) {
    var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/organisationtree"
        });
        urlEvent.fire();
    }
  

})