({
    doInit : function(component, event, helper) {
        component.set("v.sppiner", true);
        component.set("v.fixCurrentDate",new Date());
        var weekValue = 'Current';
        helper.setStartAndEndDates(component,event,weekValue);
        helper.getExistingTimeLogEnrty(component,event,helper);
        helper.disableTimeLog(component,event,helper);
      
        var action = component.get("c.fetchUser");
       
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set('v.oUser', res);
                component.set("v.sppiner", false);
            }else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set("v.sppiner", false);
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    component.set("v.sppiner", false);
                    console.log("Unknown error");
                }
            }
            
        });
        $A.enqueueAction(action);	
    },
  
    handlePreviousWeek : function(component, event, helper) {
        component.set("v.sppiner", true);
        var weekValue = 'Previous';
        helper.reset(component,event,weekValue);
    },
    handleNextWeek : function(component, event, helper) {
        component.set("v.sppiner", true);
        var weekValue = 'Next';
        helper.reset(component,event,weekValue);
    },
    addFR :function(component, event, helper) {
        helper.addFR1(component,event,helper);    
    },
    SaveTimeLog :function(component, event, helper) {
        component.set("v.sppiner", true);
        helper.createTimeLog(component,event,helper);
        
        
    },
    ResetTimeLog : function(component,event,helper){
        helper.reset(component,event,helper);
        helper.deleteOnReset(component,event,helper);
    },
    ShowPreviousWeek : function(component, event, helper){
        component.set("v.spinner", true);
        helper.getPreviousWeekTimeLogEnrties(component, event, helper);
    },
    CallApprovalProcess : function(component, event, helper){
        component.set("v.sppiner", true);
        helper.createTimeLog(component,event,helper);
        var action = component.get("c.callApprovalProcess");
        action.setParams({
            WSD : component.get("v.weekStartDate"),
            WED : component.get("v.weekEndDate"),
            usr : component.get("v.oUser")
        })
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                helper.disableTimeLog(component,event,helper);
            }else{
                component.set("v.sppiner", false);
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    onCancel : function (component, event, helper) {
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/s/time-log-entries/Time_Log_Entries__c/Default"
        });
        urlEvent.fire();
    }
})