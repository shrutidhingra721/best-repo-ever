({
	pressMe : function(component, event, helper) {
        var urlEvent = $A.get("e.force:navigateToURL");
       urlEvent.setParams({
           "url": "/calender"
       });
       urlEvent.fire();
		
	},
    
	click : function(component, event, helper) {
       var urlEvent = $A.get("e.force:navigateToURL");
       urlEvent.setParams({
           "url": "/myfiles"
       });
       urlEvent.fire();
		
	},
    
 testmeth : function(component, event, helper) {   
 $A.get('e.force:refreshView').fire();
    },
    
})