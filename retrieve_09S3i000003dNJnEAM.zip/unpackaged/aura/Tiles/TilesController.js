({ 
    doInit: function(component, event, helper) {  
       var action = component.get('c.getRemainingMatLeaves');  
       var action1 = component.get('c.getRemainingEarnedLeaves');
       var action2 = component.get('c.getRemainingSickLeaves');
       var action3 = component.get('c.getRemainingCompLeaves');
    action.setCallback(this, function(response) {    
         var state = response.getState();  
        console.log(response);
        if (state === "SUCCESS") { 
            
            component.set("v.nummat", response.getReturnValue());   
        }  
    });  
    $A.enqueueAction(action); 
        action1.setCallback(this, function(response) {    
         var state = response.getState();  
        console.log(response);
        if (state === "SUCCESS") { 
            var responseValue = response.getReturnValue();
            component.set("v.numearn",response.getReturnValue());
            
        }  
    });  
    $A.enqueueAction(action1); 
     action2.setCallback(this, function(response) {    
         var state = response.getState();  
        console.log(response);
        if (state === "SUCCESS") { 
            var responseValue = response.getReturnValue();
            component.set("v.numsick",response.getReturnValue());
            
        }  
    });  
    $A.enqueueAction(action2); 
         action3.setCallback(this, function(response) {    
         var state = response.getState();  
        console.log(response);
        if (state === "SUCCESS") {    
            component.set("v.numcomp", response.getReturnValue());   
        }  
    });  
    $A.enqueueAction(action3); 
}, 
     doInit1: function(component, event, helper) {  
       var action = component.get('c.getGender');
       var action1 = component.get('c.getRemainingPatLeaves'); 
    action.setCallback(this, function(response) {    
         var state = response.getState();  
        console.log(response);
        if (state === "SUCCESS") {  
            component.set("v.ifexists", response.getReturnValue());   
        }  
    });  
    $A.enqueueAction(action); 
         action1.setCallback(this, function(response) {    
         var state = response.getState();  
        console.log(response);
        if (state === "SUCCESS") {  
            component.set("v.numpat", response.getReturnValue());   
        }  
    });  
    $A.enqueueAction(action1); 
}

               /*  onEarned:function(component, event, helper) {
                component.set('v.mycolumns', [
                      {
                label: 'View',
                type: 'button-icon',
                initialWidth: 75,
                typeAttributes: {
                    iconName: 'action:preview',
                    title: 'Preview',
                    variant: 'border-filled',
                    alternativeText: 'View'}
                },
                {label: 'Type Of Leave', fieldName: 'Leave_Type__c', type: 'text'},
               {label: 'Status', fieldName: 'Status__c', type: 'picklist',sortable:true},
              {label: 'From Date', fieldName: 'From_Date__c', type: 'Date'},
              {label: 'To Date', fieldName: 'To_Date__c', type: 'Date'}
            ]);
        var action = component.get("c.getLeavesbasedonType");
        action.setParams({
            'Type':'Earned Leave'
        });
     action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log(response);
                component.set("v.emp1", response.getReturnValue());
            }
         });

$A.enqueueAction(action,false);
             
},
  
  onComp:function(component, event, helper) {
         component.set('v.mycolumns', [
               {
                label: 'View',
                type: 'button-icon',
                initialWidth: 75,
                typeAttributes: {
                    iconName: 'action:preview',
                    title: 'Preview',
                    variant: 'border-filled',
                    alternativeText: 'View'}
                },
                {label: 'Type Of Leave', fieldName: 'Leave_Type__c', type: 'text'},
                {label: 'Status', fieldName: 'Status__c', type: 'picklist',sortable:true},
             	{label: 'From Date', fieldName: 'From_Date__c', type: 'Date'},
             	{label: 'To Date', fieldName: 'To_Date__c', type: 'Date'}
            ]);
        var action = component.get("c.getLeavesbasedonType");
        action.setParams({
            'Type':'Compensatory Leave'
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.emp1", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },

  		onSick:function(component, event, helper) {
      component.set('v.mycolumns', [
            {
                label: 'View',
                type: 'button-icon',
                initialWidth: 75,
                typeAttributes: {
                    iconName: 'action:preview',
                    title: 'Preview',
                    variant: 'border-filled',
                    alternativeText: 'View'}
                },
                {label: 'Type Of Leave', fieldName: 'Leave_Type__c', type: 'text'},
                {label: 'Status', fieldName: 'Status__c', type: 'picklist',sortable:true},
             	{label: 'From Date', fieldName: 'From_Date__c', type: 'Date'},
             	{label: 'To Date', fieldName: 'To_Date__c', type: 'Date'}
            ]);
        var action = component.get("c.getLeavesbasedonType");
             action.setParams({
            'Type':'Sick Leave'
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.emp1", response.getReturnValue());
            }
         });

		$A.enqueueAction(action,false);
             
	},
  		onMat:function(component, event, helper) {
        component.set('v.mycolumns', [
              {
                label: 'View',
                type: 'button-icon',
                initialWidth: 75,
                typeAttributes: {
                    iconName: 'action:preview',
                    title: 'Preview',
                    variant: 'border-filled',
                    alternativeText: 'View'}
                },
                {label: 'Type Of Leave', fieldName: 'Leave_Type__c', type: 'text'},
                {label: 'Status', fieldName: 'Status__c', type: 'picklist',sortable:true},
             	{label: 'From Date', fieldName: 'From_Date__c', type: 'Date'},
             	{label: 'To Date', fieldName: 'To_Date__c', type: 'Date'}
            ]);
        var action = component.get("c.getLeavesbasedonType");

        action.setParams({
            'Type':'Maternity Leave'
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.emp1", response.getReturnValue());
            }
         });

		$A.enqueueAction(action,false);
             
	},*/
  
 
 
 
 })