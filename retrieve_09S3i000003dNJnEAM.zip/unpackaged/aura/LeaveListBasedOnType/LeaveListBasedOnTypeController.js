({
	doInit : function(component, event, helper) {
         component.set('v.mycolumns', [
            {label: 'Employee Name', fieldName: 'Employees__c', type: 'text'},
                {label: 'Type Of Leave', fieldName: 'Leave_Type__c', type: 'text'},
                {label: 'No. of days', fieldName: 'No_Of_Days__c', type: 'Number'},
             	{label: 'From Date', fieldName: 'From_Date__c', type: 'Date'},
             	{label: 'To Date', fieldName: 'To_Date__c', type: 'Date'}
            ]);
        var action = component.get('c.getLeavesbasedonType');
        action.setParams({
            'Type':'Sick Leave'
        });
        action.setCallback(this , function(response){
            var responseValue = response.getReturnValue();
            console.log('responseValue',responseValue);
            component.set('v.leavelist',responseValue);
            
        });
		$A.enqueueAction(action,false);
	}
})