<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>NA Production</label>
    <protected>false</protected>
    <values>
        <field>Connected_App_Name_SF1__c</field>
        <value xsi:type="xsd:string">Conga_Composer_SF1</value>
    </values>
    <values>
        <field>Connected_App_Name__c</field>
        <value xsi:type="xsd:string">Conga_Composer</value>
    </values>
    <values>
        <field>Hostname__c</field>
        <value xsi:type="xsd:string">composer.congamerge.com</value>
    </values>
</CustomMetadata>
